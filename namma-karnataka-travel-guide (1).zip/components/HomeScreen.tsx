
import React, { useState } from 'react';
import { Language } from '../types';
import { getCategoriesByLanguage } from '../constants';
import { ChatIcon } from './icons';

interface HomeScreenProps {
  onNavigateToChat: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigateToChat }) => {
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);

  const toggleLanguage = () => {
    setLanguage(prev => prev === Language.ENGLISH ? Language.KANNADA : Language.ENGLISH);
  };

  const categories = getCategoriesByLanguage(language);

  return (
    <div className="relative min-h-screen">
      <header className="absolute top-0 left-0 right-0 z-10 p-4 flex justify-between items-center bg-black bg-opacity-30">
        <h1 className="text-2xl md:text-3xl font-bold text-white tracking-wider">
          {language === Language.ENGLISH ? 'Explore Karnataka' : 'ಕರ್ನಾಟಕ ಅನ್ವೇಷಿಸಿ'}
        </h1>
        <button
          onClick={toggleLanguage}
          className="px-4 py-2 bg-white text-black font-semibold rounded-lg shadow-md hover:bg-yellow-200 transition-colors"
        >
          {language === Language.ENGLISH ? 'ಕನ್ನಡ' : 'English'}
        </button>
      </header>

      <main>
        {categories.map((category, index) => (
          <section
            key={category.id}
            className="h-screen bg-cover bg-center flex flex-col justify-center items-center text-white relative snap-start"
            style={{ backgroundImage: `url(${category.backgroundImage})` }}
          >
            <div className="absolute inset-0 bg-black bg-opacity-50"></div>
            <div className="z-10 text-center p-4">
              <h2 className="text-4xl md:text-6xl font-extrabold mb-4 drop-shadow-lg">{category.title}</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
                {category.places.map(place => (
                  <div key={place.id} className="bg-white bg-opacity-20 backdrop-blur-sm p-4 rounded-lg">
                    <h3 className="text-xl font-bold text-yellow-300">{place.name}</h3>
                    <p className="text-sm mt-1">{place.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ))}
      </main>

      <button
        onClick={onNavigateToChat}
        className="fixed bottom-6 right-6 z-20 w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center shadow-2xl hover:bg-red-600 transition-transform transform hover:scale-110"
        aria-label="Open Chat"
      >
        <ChatIcon className="w-8 h-8" />
      </button>
    </div>
  );
};

export default HomeScreen;
