
import React, { useState, useEffect, useRef } from 'react';
import { getChatSession } from '../services/geminiService';
import { ChatMessage, Language } from '../types';
import { CHATBOT_NAME } from '../constants';
import { SendIcon, BackArrowIcon } from './icons';
import type { Chat } from '@google/genai';

interface ChatScreenProps {
  onNavigateToHome: () => void;
}

const suggestions: { [key in Language]: string[] } = {
  [Language.ENGLISH]: ['Places', 'Rivers', 'Foods', 'Chaat', 'Restaurants', 'Hills', 'Historical Places'],
  [Language.KANNADA]: ['ಸ್ಥಳಗಳು', 'ನದಿಗಳು', 'ಆಹಾರಗಳು', 'ಚಾಟ್', 'ರೆಸ್ಟೋರೆಂಟ್‌ಗಳು', 'ಬೆಟ್ಟಗಳು', 'ಐತಿಹಾಸಿಕ ಸ್ಥಳಗಳು']
};

const ChatScreen: React.FC<ChatScreenProps> = ({ onNavigateToHome }) => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setChat(getChatSession(language));
    const initialMessage = language === Language.ENGLISH
      ? 'Hello! How can I help you explore Karnataka today?'
      : 'ನಮಸ್ಕಾರ! ಇಂದು ಕರ್ನಾಟಕವನ್ನು ಅನ್ವೇಷಿಸಲು ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?';
    setMessages([{ role: 'model', text: initialMessage }]);
  }, [language]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isLoading]);
  
  const toggleLanguage = () => {
    setLanguage(prev => prev === Language.ENGLISH ? Language.KANNADA : Language.ENGLISH);
  };

  const sendMessage = async (messageText: string) => {
    if (!messageText.trim() || isLoading || !chat) return;

    const newUserMessage: ChatMessage = { role: 'user', text: messageText };
    setMessages(prev => [...prev, newUserMessage]);
    setUserInput('');
    setIsLoading(true);

    try {
      const stream = await chat.sendMessageStream({ message: messageText });
      
      let modelResponse = '';
      setMessages(prev => [...prev, { role: 'model', text: '' }]);

      for await (const chunk of stream) {
        modelResponse += chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = modelResponse;
          return newMessages;
        });
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage = language === Language.ENGLISH
        ? 'Sorry, I encountered an error. Please try again.'
        : 'ಕ್ಷಮಿಸಿ, ದೋಷ ಕಂಡುಬಂದಿದೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.';
      setMessages(prev => {
        const lastMessage = prev[prev.length - 1];
        if (lastMessage.role === 'model' && lastMessage.text === '') {
           const newMessages = [...prev];
           newMessages[newMessages.length - 1].text = errorMessage;
           return newMessages;
        }
        return [...prev, { role: 'model', text: errorMessage }];
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(userInput);
  };
  
  const handleSuggestionClick = (suggestion: string) => {
    sendMessage(suggestion);
  };

  const placeholderText = language === Language.ENGLISH ? 'Ask about Karnataka...' : 'ಕರ್ನಾಟಕದ ಬಗ್ಗೆ ಕೇಳಿ...';

  return (
    <div 
      className="h-screen w-screen flex flex-col bg-cover bg-center"
      style={{ backgroundImage: "url('https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?q=80&w=1920&auto=format&fit=crop')" }}
    >
      <div className="absolute inset-0 bg-yellow-400 bg-opacity-20"></div>
      <div className="relative flex flex-col h-full bg-white/30 backdrop-blur-md">
        <header className="flex items-center justify-between p-4 bg-cream-100/50 backdrop-blur-sm text-black shadow-md z-10">
          <div className="flex items-center">
            <button onClick={onNavigateToHome} className="mr-4 p-2 rounded-full hover:bg-black/10">
              <BackArrowIcon className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold">{CHATBOT_NAME}</h1>
          </div>
          <button
            onClick={toggleLanguage}
            className="px-4 py-2 bg-white text-black font-semibold rounded-lg shadow-md hover:bg-yellow-200 transition-colors"
          >
            {language === Language.ENGLISH ? 'ಕನ್ನಡ' : 'English'}
          </button>
        </header>

        <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, index) => (
            <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-xs md:max-w-md lg:max-w-2xl px-4 py-2 rounded-2xl shadow ${
                  msg.role === 'user'
                    ? 'bg-red-100 text-black rounded-br-none'
                    : 'bg-white text-black rounded-bl-none'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
              </div>
            </div>
          ))}
          {isLoading && messages[messages.length - 1].role === 'user' && (
             <div className="flex justify-start">
               <div className="max-w-xs px-4 py-2 rounded-2xl shadow bg-white text-black rounded-bl-none">
                 <div className="flex items-center space-x-1">
                   <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                   <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                   <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                 </div>
               </div>
             </div>
          )}
        </main>
        
        <footer className="p-4 bg-cream-100/50 backdrop-blur-sm border-t border-white/20">
          <div className="mb-3">
            <p className="text-sm font-semibold text-black mb-2">{language === Language.ENGLISH ? 'Quick suggestions:' : 'ತ್ವರಿತ ಸಲಹೆಗಳು:'}</p>
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
                 {suggestions[language].map((suggestion, index) => (
                    <button
                        key={index}
                        onClick={() => handleSuggestionClick(suggestion)}
                        disabled={isLoading}
                        className="px-3 py-1.5 bg-white/30 text-black font-medium rounded-full whitespace-nowrap hover:bg-white/50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                    >
                        {suggestion}
                    </button>
                ))}
            </div>
          </div>
          <form onSubmit={handleFormSubmit} className="flex items-center space-x-2">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder={placeholderText}
              className="flex-1 p-3 border-2 border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-red-400 transition"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !userInput.trim()}
              className="w-12 h-12 bg-red-500 text-white rounded-full flex items-center justify-center disabled:bg-gray-400 transition-colors"
            >
              <SendIcon className="w-6 h-6" />
            </button>
          </form>
        </footer>
      </div>
    </div>
  );
};

export default ChatScreen;
