
export enum Language {
  ENGLISH = 'en',
  KANNADA = 'kn',
}

export interface Place {
  id: number;
  name: string;
  description: string;
}

export interface Category {
  id: string;
  title: string;
  places: Place[];
  backgroundImage: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
