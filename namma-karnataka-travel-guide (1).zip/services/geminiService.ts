import { GoogleGenAI, Chat } from "@google/genai";
import { Language } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

let enChat: Chat | null = null;
let knChat: Chat | null = null;

export const getChatSession = (language: Language): Chat => {
  if (language === Language.ENGLISH) {
    if (enChat) {
      return enChat;
    }
    enChat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: "You are 'Namma Karnataka Travel Guide', an expert on tourism in the state of Karnataka, India. Answer all questions related to travel, places, food, culture, and heritage of Karnataka. Be friendly and helpful. Respond only to questions about Karnataka.",
      },
    });
    return enChat;
  } else {
    if (knChat) {
      return knChat;
    }
    knChat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: "ನೀವು 'ನಮ್ಮ ಕರ್ನಾಟಕ ಪ್ರವಾಸಿ ಮಾರ್ಗದರ್ಶಿ', ಭಾರತದ ಕರ್ನಾಟಕ ರಾಜ್ಯದ ಪ್ರವಾಸೋದ್ಯಮದ ತಜ್ಞರು. ಕರ್ನಾಟಕದ ಪ್ರವಾಸ, ಸ್ಥಳಗಳು, ಆಹಾರ, ಸಂಸ್ಕೃತಿ ಮತ್ತು ಪರಂಪರೆಗೆ ಸಂಬಂಧಿಸಿದ ಎಲ್ಲಾ ಪ್ರಶ್ನೆಗಳಿಗೆ ಉತ್ತರಿಸಿ. ಸ್ನೇಹಪರವಾಗಿ ಮತ್ತು ಸಹಾಯಕವಾಗಿರಿ. ಕೇವಲ ಕರ್ನಾಟಕದ ಕುರಿತ ಪ್ರಶ್ನೆಗಳಿಗೆ ಮಾತ್ರ ಉತ್ತರಿಸಿ.",
      },
    });
    return knChat;
  }
};