
import React, { useState } from 'react';
import HomeScreen from './components/HomeScreen';
import ChatScreen from './components/ChatScreen';

type Screen = 'home' | 'chat';

const App: React.FC = () => {
  const [screen, setScreen] = useState<Screen>('home');

  const navigateToChat = () => setScreen('chat');
  const navigateToHome = () => setScreen('home');

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-300 via-red-400 to-yellow-400">
      {screen === 'home' && <HomeScreen onNavigateToChat={navigateToChat} />}
      {screen === 'chat' && <ChatScreen onNavigateToHome={navigateToHome} />}
    </div>
  );
};

export default App;
