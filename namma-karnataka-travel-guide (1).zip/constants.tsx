import { Category, Language } from './types';

export const CHATBOT_NAME = 'Namma Karnataka Travel Guide';

const CATEGORIES_DATA: { [key in Language]: Category[] } = {
  en: [
    {
      id: 'heritage',
      title: 'Heritage Places',
      backgroundImage: 'https://picsum.photos/seed/mysore_palace/1200/800',
      places: [
        { id: 1, name: 'Mysore Palace', description: 'A historical palace and the royal residence at Mysore.' },
        { id: 2, name: 'Hampi', description: 'A UNESCO World Heritage Site with ancient ruins.' },
        { id: 3, name: 'Belur & Halebidu', description: 'Temples known for their intricate Hoysala architecture.' },
        { id: 4, name: 'Badami Caves', description: 'A complex of four Hindu, Jain and Buddhist cave temples.' },
        { id: 5, name: 'Gol Gumbaz', description: 'The mausoleum of king Mohammed Adil Shah, noted for its massive dome.' },
        { id: 6, name: 'Shravanabelagola', description: 'A major Jain pilgrimage center with a giant monolithic statue of Gommateshwara.' },
        { id: 7, name: 'Aihole & Pattadakal', description: 'Historical sites known as the cradle of Indian temple architecture.' },
        { id: 8, name: 'Bidar Fort', description: 'A historic fort in the city of Bidar, known for its intricate Persian architecture.' }
      ],
    },
    {
      id: 'hills',
      title: 'Hill Stations',
      backgroundImage: 'https://picsum.photos/seed/coorg_hills/1200/800',
      places: [
        { id: 1, name: 'Coorg (Kodagu)', description: 'Known as the Scotland of India, famous for coffee plantations.' },
        { id: 2, name: 'Chikmagalur', description: 'The land of coffee, with lush green hills and serene climate.' },
        { id: 3, name: 'Kemmangundi', description: 'A beautiful hill station with spectacular sunset views.' },
        { id: 4, name: 'Nandi Hills', description: 'An ancient hill fortress, popular for sunrise views near Bangalore.' },
        { id: 5, name: 'BR Hills', description: 'Biligirirangana Hills, a serene spot where the Western and Eastern Ghats meet.' },
        { id: 6, name: 'Agumbe', description: 'Known for its scenic beauty and rainforests, often called the "Cherrapunji of the South".' },
        { id: 7, name: 'Sakleshpur', description: 'A small town in the Western Ghats, famous for its coffee and spice plantations.' },
        { id: 8, name: 'Madikeri', description: 'The capital of Coorg district, offering panoramic views and the famous Raja\'s Seat.' }
      ],
    },
    {
      id: 'waterfalls',
      title: 'Rivers & Waterfalls',
      backgroundImage: 'https://picsum.photos/seed/jog_falls/1200/800',
      places: [
        { id: 1, name: 'Jog Falls', description: 'The second-highest plunge waterfall in India.' },
        { id: 2, name: 'Abbey Falls', description: 'A stunning waterfall located amidst coffee plantations in Coorg.' },
        { id: 3, name: 'Shivanasamudra Falls', description: 'A majestic segmented waterfall on the Kaveri river.' },
        { id: 4, name: 'Gokak Falls', description: 'A beautiful waterfall on the Ghataprabha River, known for its horseshoe shape.' },
        { id: 5, name: 'Iruppu Falls', description: 'A picturesque waterfall in the Brahmagiri Range in Coorg district.' },
        { id: 6, name: 'Magod Falls', description: 'A group of waterfalls where the Bedti river plunges from a height.' },
        { id: 7, name: 'Hebbe Falls', description: 'Located within a coffee estate in Kemmangundi, it cascades down in two stages.' },
        { id: 8, name: 'Unchalli Falls', description: 'Also known as Lushington Falls, created by a 116-meter drop in the Aghanashini River.' }
      ],
    },
    {
      id: 'food',
      title: 'Restaurants & Chaat',
      backgroundImage: 'https://picsum.photos/seed/karnataka_food/1200/800',
      places: [
        { id: 1, name: 'Mavalli Tiffin Rooms (MTR)', description: 'A legendary restaurant in Bangalore famous for authentic Karnataka cuisine.' },
        { id: 2, name: 'Vidyarthi Bhavan', description: 'Iconic for its crispy Masala Dosa in Bangalore.' },
        { id: 3, name: 'VV Puram Food Street', description: 'A bustling street food paradise in Bangalore offering a variety of chaats.' },
        { id: 4, name: 'CTR (Shri Sagar)', description: 'Famous for its delectable Benne Masala Dosa in Malleshwaram, Bangalore.' },
        { id: 5, name: 'Taaza Thindi', description: 'A popular eatery in Jayanagar, Bangalore, known for its quick, affordable, and tasty South Indian breakfast.' },
        { id: 6, name: 'Koshy\'s Parade Cafe', description: 'A Bangalore institution known for its old-world charm and Anglo-Indian cuisine.' },
        { id: 7, name: 'Halli Mane', description: 'Offers a rustic, village-like ambiance and traditional Karnataka meals in Malleshwaram.' },
        { id: 8, name: 'Karnataka Bhel House', description: 'A famous spot in Chamarajpet, Bangalore for its delicious Bhel Puri.' }
      ],
    },
  ],
  kn: [
    {
      id: 'heritage',
      title: 'ಪರಂಪರೆಯ ಸ್ಥಳಗಳು',
      backgroundImage: 'https://picsum.photos/seed/mysore_palace/1200/800',
      places: [
        { id: 1, name: 'ಮೈಸೂರು ಅರಮನೆ', description: 'ಮೈಸೂರಿನಲ್ಲಿರುವ ಒಂದು ಐತಿಹಾಸಿಕ ಅರಮನೆ ಮತ್ತು ರಾಜಮನೆತನದ ನಿವಾಸ.' },
        { id: 2, name: 'ಹಂಪಿ', description: 'ಯುನೆಸ್ಕೋ ವಿಶ್ವ ಪರಂಪರೆಯ ತಾಣ, ಪ್ರಾಚೀನ ಅವಶೇಷಗಳನ್ನು ಹೊಂದಿದೆ.' },
        { id: 3, name: 'ಬೇಲೂರು ಮತ್ತು ಹಳೇಬೀಡು', description: 'ಹೊಯ್ಸಳ ವಾಸ್ತುಶಿಲ್ಪಕ್ಕೆ ಹೆಸರುವಾಸಿಯಾದ ದೇವಾಲಯಗಳು.' },
        { id: 4, name: 'ಬಾದಾಮಿ ಗುಹೆಗಳು', description: 'ನಾಲ್ಕು ಹಿಂದೂ, ಜೈನ ಮತ್ತು ಬೌದ್ಧ ಗುಹಾ ದೇವಾಲಯಗಳ ಸಂಕೀರ್ಣ.' },
        { id: 5, name: 'ಗೋಲ ಗುಮ್ಮಟ', description: 'ರಾಜ ಮೊಹಮ್ಮದ್ ಆದಿಲ್ ಷಾ ಅವರ ಸಮಾಧಿ, ಅದರ ಬೃಹತ್ ಗುಮ್ಮಟಕ್ಕೆ ಹೆಸರುವಾಸಿಯಾಗಿದೆ.' },
        { id: 6, name: 'ಶ್ರವಣಬೆಳಗೊಳ', description: 'ಗೊಮ್ಮಟೇಶ್ವರನ ಬೃಹತ್ ಏಕಶಿಲಾ ಪ್ರತಿಮೆಯನ್ನು ಹೊಂದಿರುವ ಪ್ರಮುಖ ಜೈನ ಯಾತ್ರಾ ಕೇಂದ್ರ.' },
        { id: 7, name: 'ಐಹೊಳೆ ಮತ್ತು ಪಟ್ಟದಕಲ್ಲು', description: 'ಭಾರತೀಯ ದೇವಾಲಯ ವಾಸ್ತುಶಿಲ್ಪದ ತೊಟ್ಟಿಲು ಎಂದು ಕರೆಯಲ್ಪಡುವ ಐತಿಹಾಸಿಕ ಸ್ಥಳಗಳು.' },
        { id: 8, name: 'ಬೀದರ್ ಕೋಟೆ', description: 'ಬೀದರ್ ನಗರದಲ್ಲಿರುವ ಒಂದು ಐತಿಹಾಸಿಕ ಕೋಟೆ, ಅದರ ಸಂಕೀರ್ಣ ಪರ್ಷಿಯನ್ ವಾಸ್ತುಶಿಲ್ಪಕ್ಕೆ ಹೆಸರುವಾಸಿಯಾಗಿದೆ.' }
      ],
    },
    {
      id: 'hills',
      title: 'ಗಿರಿಧಾಮಗಳು',
      backgroundImage: 'https://picsum.photos/seed/coorg_hills/1200/800',
      places: [
        { id: 1, name: 'ಕೊಡಗು (ಕೂರ್ಗ್)', description: 'ಭಾರತದ ಸ್ಕಾಟ್ಲೆಂಡ್ ಎಂದು ಕರೆಯಲ್ಪಡುತ್ತದೆ, ಕಾಫಿ ತೋಟಗಳಿಗೆ ಪ್ರಸಿದ್ಧವಾಗಿದೆ.' },
        { id: 2, name: 'ಚಿಕ್ಕಮಗಳೂರು', description: 'ಕಾಫಿಯ ನಾಡು, ಹಸಿರು ಬೆಟ್ಟಗಳು ಮತ್ತು ಪ್ರಶಾಂತ ವಾತಾವರಣ.' },
        { id: 3, name: 'ಕೆಮ್ಮಣ್ಣುಗುಂಡಿ', description: 'ಸುಂದರವಾದ ಗಿರಿಧಾಮ, ಅದ್ಭುತ ಸೂರ್ಯಾಸ್ತದ ನೋಟಗಳನ್ನು ಹೊಂದಿದೆ.' },
        { id: 4, name: 'ನಂದಿ ಬೆಟ್ಟ', description: 'ಬೆಂಗಳೂರಿನ ಸಮೀಪ ಸೂರ್ಯೋದಯದ ನೋಟಗಳಿಗೆ ಜನಪ್ರಿಯವಾದ ಪ್ರಾಚೀನ ಗಿರಿ ದುರ್ಗ.' },
        { id: 5, name: 'ಬಿಆರ್ ಹಿಲ್ಸ್', description: 'ಬಿಳಿಗಿರಿರಂಗನ ಬೆಟ್ಟ, ಪಶ್ಚಿಮ ಮತ್ತು ಪೂರ್ವ ಘಟ್ಟಗಳು ಸೇರುವ ಪ್ರಶಾಂತ ಸ್ಥಳ.' },
        { id: 6, name: 'ಆಗುಂಬೆ', description: '"ದಕ್ಷಿಣದ ಚಿರಾಪುಂಜಿ" ಎಂದು ಕರೆಯಲ್ಪಡುವ, ತನ್ನ ಸುಂದರ ದೃಶ್ಯಾವಳಿ ಮತ್ತು ಮಳೆಕಾಡುಗಳಿಗೆ ಹೆಸರುವಾಸಿ.' },
        { id: 7, name: 'ಸಕಲೇಶಪುರ', description: 'ಪಶ್ಚಿಮ ಘಟ್ಟಗಳಲ್ಲಿರುವ ಒಂದು ಸಣ್ಣ ಪಟ್ಟಣ, ಕಾಫಿ ಮತ್ತು ಮಸಾಲೆ ತೋಟಗಳಿಗೆ ಪ್ರಸಿದ್ಧ.' },
        { id: 8, name: 'ಮಡಿಕೇರಿ', description: 'ಕೊಡಗು ಜಿಲ್ಲೆಯ ರಾಜಧಾನಿ, ಸುಂದರ ನೋಟಗಳು ಮತ್ತು ಪ್ರಸಿದ್ಧ ರಾಜಾಸೀಟ್ ಅನ್ನು ಹೊಂದಿದೆ.' }
      ],
    },
    {
      id: 'waterfalls',
      title: 'ನದಿಗಳು ಮತ್ತು ಜಲಪಾತಗಳು',
      backgroundImage: 'https://picsum.photos/seed/jog_falls/1200/800',
      places: [
        { id: 1, name: 'ಜೋಗ ಜಲಪಾತ', description: 'ಭಾರತದ ಎರಡನೇ ಅತಿ ಎತ್ತರದ ಧುಮ್ಮಿಕ್ಕುವ ಜಲಪಾತ.' },
        { id: 2, name: 'ಅಬ್ಬೆ ಜಲಪಾತ', description: 'ಕೊಡಗಿನ ಕಾಫಿ ತೋಟಗಳ ನಡುವೆ ಇರುವ ಸುಂದರ ಜಲಪಾತ.' },
        { id: 3, name: 'ಶಿವನಸಮುದ್ರ ಜಲಪಾತ', description: 'ಕಾವೇರಿ ನದಿಯ ಮೇಲಿರುವ ಭವ್ಯವಾದ ಜಲಪಾತ.' },
        { id: 4, name: 'ಗೋಕಾಕ್ ಜಲಪಾತ', description: 'ಘಟಪ್ರಭಾ ನದಿಯ ಮೇಲಿರುವ ಸುಂದರ ಜಲಪಾತ, ಕುದುರೆ ಲಾಳದ ಆಕಾರಕ್ಕೆ ಹೆಸರುವಾಸಿ.' },
        { id: 5, name: 'ಇರುಪ್ಪು ಜಲಪಾತ', description: 'ಕೊಡಗು ಜಿಲ್ಲೆಯ ಬ್ರಹ್ಮಗಿರಿ ಶ್ರೇಣಿಯಲ್ಲಿರುವ ಸುಂದರ ಜಲಪಾತ.' },
        { id: 6, name: 'ಮಾಗೋಡು ಜಲಪಾತ', description: 'ಪಶ್ಚಿಮ ಘಟ್ಟಗಳಲ್ಲಿರುವ ಜಲಪಾತಗಳ ಸಮೂಹ, ಇಲ್ಲಿ ಬೇಡ್ತಿ ನದಿ ಎತ್ತರದಿಂದ ಧುಮುಕುತ್ತದೆ.' },
        { id: 7, name: 'ಹೆಬ್ಬೆ ಜಲಪಾತ', description: 'ಕೆಮ್ಮಣ್ಣುಗುಂಡಿಯ ಕಾಫಿ ಎಸ್ಟೇಟ್‌ನಲ್ಲಿದೆ, ಇದು ಎರಡು ಹಂತಗಳಲ್ಲಿ ಧುಮುಕುತ್ತದೆ.' },
        { id: 8, name: 'ಉಂಚಳ್ಳಿ ಜಲಪಾತ', description: 'ಲಷಿಂಗ್ಟನ್ ಜಲಪಾತ ಎಂದೂ ಕರೆಯಲ್ಪಡುತ್ತದೆ, ಅಘನಾಶಿನಿ ನದಿಯಲ್ಲಿ 116 ಮೀಟರ್ ಎತ್ತರದಿಂದ ಧುಮುಕುತ್ತದೆ.' }
      ],
    },
    {
      id: 'food',
      title: 'ರೆಸ್ಟೋರೆಂಟ್‌ಗಳು ಮತ್ತು ಚಾಟ್',
      backgroundImage: 'https://picsum.photos/seed/karnataka_food/1200/800',
      places: [
        { id: 1, name: 'ಮಾವಳ್ಳಿ ಟಿಫಿನ್ ರೂಮ್ಸ್ (MTR)', description: 'ಬೆಂಗಳೂರಿನಲ್ಲಿರುವ ಪಾರಂಪರಿಕ ಕರ್ನಾಟಕದ ಖಾದ್ಯಗಳಿಗೆ ಪ್ರಸಿದ್ಧವಾದ ರೆಸ್ಟೋರೆಂಟ್.' },
        { id: 2, name: 'ವಿದ್ಯಾರ್ಥಿ ಭವನ', description: 'ಬೆಂಗಳೂರಿನಲ್ಲಿ ಗರಿಗರಿಯಾದ ಮಸಾಲ ದೋಸೆಗೆ ಹೆಸರುವಾಸಿ.' },
        { id: 3, name: 'ವಿ.ವಿ. ಪುರಂ ಫುಡ್ ಸ್ಟ್ರೀಟ್', description: 'ಬೆಂಗಳೂರಿನಲ್ಲಿ ವಿವಿಧ ಚಾಟ್‌ಗಳನ್ನು ನೀಡುವ ಬೀದಿ ಆಹಾರದ ಸ್ವರ್ಗ.' },
        { id: 4, name: 'ಸಿಟಿಆರ್ (ಶ್ರೀ ಸಾಗರ್)', description: 'ಬೆಂಗಳೂರಿನ ಮಲ್ಲೇಶ್ವರಂನಲ್ಲಿ ರುಚಿಕರವಾದ ಬೆಣ್ಣೆ ಮಸಾಲ ದೋಸೆಗೆ ಪ್ರಸಿದ್ಧವಾಗಿದೆ.' },
        { id: 5, name: 'ತಾಜಾ ತಿಂಡಿ', description: 'ಬೆಂಗಳೂರಿನ ಜಯನಗರದಲ್ಲಿರುವ ಜನಪ್ರಿಯ ಉಪಹಾರ ಗೃಹ, ತ್ವರಿತ, ಕೈಗೆಟುಕುವ ಮತ್ತು ರುಚಿಕರವಾದ ದಕ್ಷಿಣ ಭಾರತೀಯ ಉಪಹಾರಕ್ಕೆ ಹೆಸರುವಾಸಿ.' },
        { id: 6, name: 'ಕೋಶಿಸ್ ಪೆರೇಡ್ ಕೆಫೆ', description: 'ಬೆಂಗಳೂರಿನ ಒಂದು ಹಳೆಯ ಸಂಸ್ಥೆ, ತನ್ನ ಹಳೆಯ ಕಾಲದ ಆಕರ್ಷಣೆ ಮತ್ತು ಆಂಗ್ಲೋ-ಇಂಡಿಯನ್ ಪಾಕಪದ್ಧತಿಗೆ ಹೆಸರುವಾಸಿ.' },
        { id: 7, name: 'ಹಳ್ಳಿ ಮನೆ', description: 'ಮಲ್ಲೇಶ್ವರಂನಲ್ಲಿ ಹಳ್ಳಿಯಂತಹ ವಾತಾವರಣ ಮತ್ತು ಸಾಂಪ್ರದಾಯಿಕ ಕರ್ನಾಟಕ ಊಟವನ್ನು ನೀಡುತ್ತದೆ.' },
        { id: 8, name: 'ಕರ್ನಾಟಕ ಭೇಲ್ ಹೌಸ್', description: 'ಚಾಮರಾಜಪೇಟೆಯಲ್ಲಿರುವ ಪ್ರಸಿದ್ಧ ಸ್ಥಳ, ತನ್ನ ರುಚಿಕರವಾದ ಭೇಲ್ ಪುರಿಗೆ ಹೆಸರುವಾಸಿ.' }
      ],
    },
  ],
};

export const getCategoriesByLanguage = (lang: Language): Category[] => CATEGORIES_DATA[lang];